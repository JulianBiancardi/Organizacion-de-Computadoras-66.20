#ifndef SPEED_TESTS_H
#define SPEED_TESTS_H

void speed_tests();

#endif

#ifndef MCD_TESTS_H
#define MCD_TESTS_H

void mcd_tests();

#endif

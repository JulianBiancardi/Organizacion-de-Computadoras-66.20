#ifndef MCM_TESTS_H
#define MCM_TESTS_H

void mcm_tests();

#endif
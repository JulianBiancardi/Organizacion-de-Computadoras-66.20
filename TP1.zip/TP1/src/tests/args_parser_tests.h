#ifndef ARGS_PARSER_TESTS_H
#define ARGS_PARSER_TESTS_H

void args_parser_tests();

#endif

#ifndef CONSTANTS_H
#define CONSTANTS_H

#define VERSION 8

// Error codes
#define ERROR -1
#define NO_ERROR 0

#define FILE_NAME_MAX_LEN 32

#define RANGE_MIN 2
#define RANGE_MAX 4294967295  // No se si es MAXINT O MAXUINT

#endif

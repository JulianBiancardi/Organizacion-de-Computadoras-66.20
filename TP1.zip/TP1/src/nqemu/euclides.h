#ifndef EUCLIDES_H
#define EUCLIDES_H

unsigned int mcd_rec(unsigned int m, unsigned int n);
unsigned int mcd(unsigned int m, unsigned int n);
unsigned int mcm(unsigned int m, unsigned int n);

#endif
